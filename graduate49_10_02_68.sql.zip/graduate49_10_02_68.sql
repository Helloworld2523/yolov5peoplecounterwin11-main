-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2025 at 03:33 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `graduate49`
--

-- --------------------------------------------------------

--
-- Table structure for table `ru_queue`
--

CREATE TABLE IF NOT EXISTS `ru_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `queue_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `total_count` int(11) NOT NULL,
  `remaining_count` int(11) NOT NULL,
  `current_count` int(11) NOT NULL,
  `counted_ids` text COLLATE utf8_unicode_ci NOT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ru_queue`
--

INSERT INTO `ru_queue` (`id`, `queue_date`, `total_count`, `remaining_count`, `current_count`, `counted_ids`, `last_updated`) VALUES
(1, '2025-01-17 09:42:24', 100, 20, 2, '', '2025-02-10 02:33:14');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
